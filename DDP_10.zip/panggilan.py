import latihan

print('--------gunakan modul-----------')
latihan.tambah(5,2)
latihan.kurang(10,3)
latihan.kali(5,6)

print('\n--gunakan modul yg ada dgn alias--')
latihan.bagi(20,2)
latihan.pangkat(2,3)

print('\n--gunakan modul dgn memanggil sebagian fungsinya--')
from latihan import tambah,kurang
tambah(20,30)
kurang(2,3)

print('\n--gunakan modul dgn memanggil seluruh fungsinya--')
from latihan import*
tambah(20,30)
kurang(2,3)
kali(5,6)
bagi(20,2)
pangkat(2,3)