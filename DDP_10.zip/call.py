import bangundatar as datar
import bangunruang as ruang



print("\n  Perhitungan Luas & Keliling Persegi")

datar.l_persegi(2)
datar.l_persegi(5)

print("===============================")
print ("\n Perhitungan Luas & Keliling Persegi Panjang")

datar.l_persegi_panjang(2,6)

print("===============================")
print("\n Perhitungan luas Segitiga")

datar.l_segita(5,8)

print("===============================")
print("\n  Perhitungan luas Lingkaran")

datar.l_lingkaran(6,8)

print("===============================")
print("\n  Perhitungan luas Jajar genjang")

datar.l_jajar_genjang(8,5)

print("===============================")
print("\n  Perhitungan luas kubus")

ruang.l_kubus (9)

print("===============================")
print("\n  Perhitungan luas balok")

ruang.l_balok (5,3,4)

print ("===============================")
print("\n  Perhitungan luas tabung")

ruang.l_tabung (4,2)

print("===============================")
print("\n  Perhitungan luas kerucut")

ruang.l_kerucut (6,7)

print ("===============================")
print("\n  Perhitungan luas bola")

ruang.l_bola (5)

